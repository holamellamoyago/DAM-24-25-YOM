package ud4.yomExamen;

public class test {
    public static void main(String[] args) {
    //  System.out.println(calcularVidas(200)); 

    // buscarLetra();

    System.out.println(sumarPuntosIndividual(" "));
    }

    public static double calcularVidas(int totalHuecos){
        
        return totalHuecos*0.1;

    }

    public static void buscarLetra(){
        String hola = "hola";

        int indice = hola.indexOf("o");

        System.out.println(indice);


    }


    static int sumarPuntosIndividual(String valorLetra) {

        int contador = 0;

        char[] valorLetraArray = valorLetra.toCharArray();


        for (int i = 0; i < valorLetra.length(); i++) {
            if (valorLetraArray[i] == ' ') {
                contador += 1;
            } else {
                System.out.println("Error");
            }
        }

        return contador;
    }
}
