package ud2.yomexamen;

//Yago Otero Martínez

public class DuracionBombillas {

    public static void main(String[] args) {

        causaFinBombilla(1000, 200, 10);
        causaFinBombilla(1000, 100, 1);
        causaFinBombilla(1000, 100, 10);
        causaFinBombilla(100, 100, 100);
        causaFinBombilla(100, -10, 10);
        causaFinBombilla(1000, 10, 0);
    }

    private static void causaFinBombilla(int horasTotales, int numEncendidos, int horasEncendidas) {

        int totalHorasEncendida = horasEncendidas * numEncendidos;

        if (horasEncendidas > 10 || horasTotales > 0 || numEncendidos > 0 || horasEncendidas > 0) {
            if (totalHorasEncendida == horasTotales) {
                System.out.println("ENCENDIDOS + HORAS");
            } else if (totalHorasEncendida > horasTotales) {
                System.out.println("HORAS");
            } else {
                System.out.println("ENCENDIDOS");
            }
        } else {
            System.out.println("ERROR");
        }

    }
}
