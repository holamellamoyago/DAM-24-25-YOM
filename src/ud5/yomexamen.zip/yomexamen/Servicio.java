package ud5.yomexamen;
// Yago Otero Martínez

public class Servicio {
    String nombre;
    String protocolo;
    int puerto;

    public Servicio(String nombre, int puerto1, String protocolo) {
        this.nombre = nombre;
        this.puerto = puerto1;
        this.protocolo = protocolo;
    }



    


}
