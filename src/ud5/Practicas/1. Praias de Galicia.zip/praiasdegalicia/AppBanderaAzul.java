package ud5.Practicas.praiasdegalicia;

public class AppBanderaAzul {
    public static void main(String[] args) {
        // Carga las playas desde el fichero JSON en un array de Praias
        Praia[] praias = Util.importarPraias("praias.json");

        // TODO Resuelve el problema propuesto
        // ...
    }
}
