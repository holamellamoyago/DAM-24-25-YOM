package ud3.EjerciciosClase.Clases;

public enum DiaDeLaSemana {
    LUNES,MARTES,MIERCOLES,JUEVES,SABADO,DOMINGO;
}
