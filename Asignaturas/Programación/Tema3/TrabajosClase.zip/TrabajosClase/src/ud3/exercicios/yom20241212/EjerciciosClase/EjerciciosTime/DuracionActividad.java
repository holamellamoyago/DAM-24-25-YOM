package ud3.EjerciciosClase.EjerciciosTime;
public class DuracionActividad {
    int k = 23;
}
