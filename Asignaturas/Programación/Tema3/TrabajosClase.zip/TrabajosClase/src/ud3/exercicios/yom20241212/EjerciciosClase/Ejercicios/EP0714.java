package ud3.EjerciciosClase.Ejercicios;

import ud3.EjerciciosClase.Clases.*;

// Crea una clase que sea capaz de mostrar el importe de un cambio, por ejemplo, al
// realizar una compra, con el menor número de monedas y billetes posibles.

public class EP0714 {
        public static void main(String[] args) {
        Caja c = new Caja(0.04);
        c.devoloverdinero();
    }
}

    