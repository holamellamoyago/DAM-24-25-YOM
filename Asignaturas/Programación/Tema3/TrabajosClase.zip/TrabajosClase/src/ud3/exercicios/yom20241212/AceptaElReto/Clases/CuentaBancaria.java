package AceptaElReto.Clases;

public class CuentaBancaria {
    // codigo cuenta cliente
    private int codCodigo;
    private int codCuenta;
    private int codCliente;

    private String nombre;
    private int codEntidad;
    private int codOficina;

    public CuentaBancaria(int codCodigo, int codCuenta, int codCliente, String nombre, int codEntidad, int codOficina) {
        this.codCodigo = codCodigo;
        this.codCuenta = codCuenta;
        this.codCliente = codCliente;
        this.nombre = nombre;
        this.codEntidad = codEntidad;
        this.codOficina = codOficina;
    }

    

    
}
