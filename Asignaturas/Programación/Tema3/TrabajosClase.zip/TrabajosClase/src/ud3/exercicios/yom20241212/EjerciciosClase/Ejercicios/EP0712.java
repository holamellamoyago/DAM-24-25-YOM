package ud3.EjerciciosClase.Ejercicios;

import ud3.EjerciciosClase.Clases.*;

public class EP0712 {
        public static void main(String[] args) {
        EcuacionSegundoGrado e = new EcuacionSegundoGrado(1,2,5);
        e.resultado();
    }   

}
