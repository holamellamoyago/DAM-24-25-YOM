package ud5.Practicas.MulleresTraballadoras.Interfaces;

public interface IPioneira {

    abstract String getDescubrimentoOuAporte();
}
