package ud5.Practicas.MulleresTraballadoras.Interfaces;

public interface IActivista {
    abstract String getCausaDefendida();
}
