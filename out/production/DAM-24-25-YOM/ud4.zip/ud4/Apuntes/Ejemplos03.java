package ud4.Apuntes;
import java.util.Arrays;
import java.util.Scanner;


public class Ejemplos03 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int edad[] = {10,27,33,37}; // Declaración y construir un array con inicializacion

        // for(int i = 0 ; i<4 ; i++){
        //     System.out.println(edad[i]);
        // }

        System.out.println(edad);
        System.out.println(Arrays.toString(edad));


    }
}
