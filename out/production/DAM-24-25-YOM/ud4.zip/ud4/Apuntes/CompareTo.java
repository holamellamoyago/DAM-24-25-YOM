package ud4.Apuntes;

import java.util.Arrays;

public class CompareTo {
    public static void main(String[] args) {
        String n1 = "Yago";
        String n2 = "Ana";


        System.out.println(n1.compareTo(n2));

        int[] l = {};

        System.out.println(Arrays.toString(l));
    }
}
