package ud4.Apuntes;
import java.util.Arrays;
import java.util.Scanner;

public class TresTablas {
    
    public static void main(String[] args) {
        
        int arrayInt [] = {1,2,3,4,5};
        double arrayDouble [] = {1.1,2.2,3.3,4.4,5.5};
        boolean arrayBooleam [] = {true,false,true,false,true};

        int resultado = arrayInt[2];
        
        System.out.println(Arrays.toString(arrayInt));
        System.out.println(arrayInt);
    }
}
