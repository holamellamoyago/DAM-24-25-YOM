package ud4.Ejercicios;

public class Empleado {
    String nombre;
    int sueldo;


    public Empleado(String nombre, int sueldo) {
        this.nombre = nombre;
        this.sueldo = sueldo;
    }


    public String getNombre() {
        return nombre;
    }


    public int getSueldo() {
        return sueldo;
    }

    

    
}
