package ud4.Ejercicios;

public class E0503 {
    
    public static void main(String[] args) {
        int l [] = E0501.arrayAleatorio(5,-10,10);
        for(int i = l.length -1; i>=0;i--){
            System.out.println(l[i] + " ");
            System.out.println();
        }
        
    }


}
