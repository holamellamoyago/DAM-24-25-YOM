package ud4.StringsApuntes;

public class Pruebas {
    public static void main(String[] args) {
        System.out.println((char)('a' +1));



        for(int i = 0; i< 512; i++){
            System.out.println(i + " -> "+  (char)i);
            


        }
    }

}
