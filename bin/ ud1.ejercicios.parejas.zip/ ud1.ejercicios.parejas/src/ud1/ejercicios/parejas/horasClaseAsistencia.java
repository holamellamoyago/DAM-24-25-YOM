package ud1.ejercicios.parejas;

import java.util.Scanner;

/**
 * horasClaseAsistencia
 */
public class horasClaseAsistencia {

    public static void main(String[] args) {
        final String nombre = "FP programacion";
        final int HORAS = 240;

        int minutostotal = 240*60;

        int clasesTotal = minutostotal / 50;

        System.out.println("Las clases total de 50min son: " + clasesTotal);

        double sesetaPorciento = (clasesTotal * 0.06) ; 
        // double primerApercibimiento = clasesTotal - sesetaPorciento;
        System.out.println("El primer aprecibimiento del 6% es al llegar a " + sesetaPorciento + " faltas");

        double cienPorciento = (clasesTotal * 10 / 100) ; 
        System.out.println("El primer aprecibimiento del 10% es al llegar a " + cienPorciento + " faltas");


        System.out.println("cuantas faltas tienes");
        Scanner sc = new Scanner(System.in);

        double clasesFaltadas =  sc.nextInt();

        clasesFaltadas <= sesetaPorciento ? System.out.println("Verdadero") : System.out.println("Falso");





    }
}