package ud1.ejercicios.parejas;

/**
 * unidadesMedidas
 */

 import java.util.Scanner;
 import java.util.Locale;
 import java.math.*;
public class unidadesMedidas {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dime cuantas hectareas hay que calcular");
        double hectareas = sc.nextDouble();

        // Campo 105 x 70 m
        double LARGOCAMPO = 105;
        double ANCHOCAMPO = 70;




        // double largoEquivalente = LARGOCAMPO / 100;
        // double anchoEquivalente = ANCHOCAMPO / 100;

        // System.out.println("Una hectarea de largo equivale a: " + largoEquivalente);
    
        // System.out.println("Una hectarea de ancho equivale a: " + anchoEquivalente);
        // System.out.println("Ancho:" + ANCHOCAMPO * hectareas);

        // double totaLlARGO = largoEquivalente *  hectareas;
        // double totalAncho = anchoEquivalente * hectareas;

        // System.out.println("El total de campos en campos de futbol equivale a: " + totaLlARGO  + "x" +  totalAncho);

        // double metrosCuadrados = (totalAncho *100) * (totaLlARGO *100);

        // System.out.println("En metros cuadrados: " + metrosCuadrados );

        // double caposTotalAncho = totalAncho / 70;
        // System.out.println("Son " + caposTotalAncho * 100 + " campos de futbol en total");


        System.out.println("Largo: " +  10000 * hectareas);
        System.out.println("Anhco: " +  10000 * hectareas);

        double largoCampoCuadrados = 105 * 10000;
        double anchoCampoCuadrados = 70 * 10000;

        double campostotal = (largoCampoCuadrados / 105) /100 ;
        System.out.println("El total de campos de futbol equivale a " + campostotal);

    
    }
}